CS612 Lecture 07 materials

Open Lecture_07/Lecture_07_Slides.html in a browser for the interactive slides.
Keep the Lecture_07 and _shared folders together at the same level. An internet connection is needed for the KaTeX CSS font styling.
The PDF slides and exercise sheets work offline.
The back-to-library link works when viewing the full course site.
