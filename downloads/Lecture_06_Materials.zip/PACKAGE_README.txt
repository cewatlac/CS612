CS612 Lecture 06 materials

Open Lecture_06/Lecture_06_Slides.html in a browser for the interactive slides.
Keep the Lecture_06 and _shared folders together at the same level. An internet connection is needed for the KaTeX CSS font styling.
The PDF slides and exercise sheets work offline.
The back-to-library link works when viewing the full course site.
